const { kill } = require('./actions')
const collector = require('./collector')

const PUSH_LIMIT = 6
const CACHE_TTL = 800

let cache = { at: 0, data: null }

async function load() {
  const now = Date.now()
  if (cache.data && now - cache.at < CACHE_TTL) return cache.data
  const data = await collector.snapshot()
  cache = { at: now, data }
  return data
}

function parseInput(text) {
  const t = String(text || '').trim()
  const m = /^(kill|netstat|port|端口|关闭进程)\s+(.*)$/i.exec(t)
  if (m) return { mode: /^(netstat|port|端口)$/i.test(m[1]) ? 'port' : 'kill', keyword: m[2].trim() }
  return { mode: 'kill', keyword: t }
}

function match(proc, mode, keyword) {
  const kw = keyword.toLowerCase()
  if (!kw) return false
  if (mode === 'port') {
    return proc.listen.some(p => String(p).includes(kw)) || proc.conn.some(p => String(p).includes(kw))
  }
  return proc.name.toLowerCase().includes(kw) || proc.path.toLowerCase().includes(kw)
}

function rank(proc, mode, keyword) {
  const kw = keyword.toLowerCase()
  if (mode === 'port') {
    const exact = proc.listen.some(p => String(p) === kw) ? 100 : 0
    return exact + proc.portCount
  }
  if (proc.name.toLowerCase() === kw) return 100
  if (proc.name.toLowerCase().startsWith(kw)) return 50
  return 0
}

async function build(text) {
  const { mode, keyword } = parseInput(text)
  if (!keyword) return []
  let data
  try {
    data = await load()
  } catch (e) {
    return []
  }
  const hits = data.processes
    .filter(p => match(p, mode, keyword))
    .sort((a, b) => rank(b, mode, keyword) - rank(a, mode, keyword) || b.mem - a.mem)

  return hits.slice(0, PUSH_LIMIT).map(p => ({
    title: p.name,
    text: p.name + '  ' + (p.listen.length ? '端口 ' + p.listen.join(', ') : p.path),
    payload: { pid: p.pid, name: p.name, mode }
  }))
}

function register(ztools) {
  ztools.onMainPush(async action => {
    const results = await build(action && action.payload)
    return results.map(r => ({ text: r.text, title: r.title }))
  }, async action => {
    const option = action && action.option
    const payload = (option && (option.payload || option)) || {}
    const pid = Number(payload.pid)
    if (!pid) return false
    const result = await kill(pid)
    ztools.showNotification(result.ok ? '已关闭 ' + (payload.name || pid) : '关闭失败：' + (result.reason || '未知原因'))
    return false
  })
}

module.exports = { register, build, parseInput, match, rank }
