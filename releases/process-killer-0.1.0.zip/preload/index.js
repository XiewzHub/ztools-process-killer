const { register } = require('./mainpush')

const ztools = window.ztools || window.utools

if (ztools && typeof ztools.onMainPush === 'function') {
  try {
    register(ztools)
  } catch (e) {
    console.warn('[process-killer] onMainPush 注册失败', e)
  }
}
