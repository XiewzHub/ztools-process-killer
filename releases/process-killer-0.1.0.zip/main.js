const svc = window.services || {}

const state = {
  all: [],
  rows: [],
  keyword: '',
  sort: 'mem',
  selected: 0,
  loading: false,
  portWarning: null
}

const $ = sel => document.querySelector(sel)
const listEl = $('#list')
const searchEl = $('#search')
const bannerEl = $('#banner')
const emptyEl = $('#empty')
const summaryEl = $('#summary')
const menuEl = $('#menu')
const toastEl = $('#toast')

const RENDER_LIMIT = 400

function fmtMem(rss) {
  const mb = rss / 1024
  return mb >= 1024 ? (mb / 1024).toFixed(1) + ' GB' : Math.round(mb) + ' MB'
}

function sortRows(rows, by) {
  const copy = rows.slice()
  if (by === 'name') copy.sort((a, b) => a.name.localeCompare(b.name))
  else if (by === 'cpu') copy.sort((a, b) => b.cpu - a.cpu)
  else if (by === 'ports') copy.sort((a, b) => b.portCount - a.portCount || b.mem - a.mem)
  else copy.sort((a, b) => b.mem - a.mem)
  return copy
}

function matches(p, keyword) {
  if (!keyword) return true
  const kw = keyword.toLowerCase()
  if (/^\d+$/.test(kw)) {
    if (String(p.pid).includes(kw)) return true
    if (p.listen.some(x => String(x).includes(kw))) return true
    if (p.conn.some(x => String(x).includes(kw))) return true
  }
  return p.name.toLowerCase().includes(kw) || p.path.toLowerCase().includes(kw)
}

function applyFilter() {
  const filtered = state.all.filter(p => matches(p, state.keyword))
  state.rows = sortRows(filtered, state.sort)
  if (state.selected >= state.rows.length) state.selected = Math.max(0, state.rows.length - 1)
  render()
}

async function loadIcons() {
  const seen = new Set()
  for (const row of state.rows.slice(0, RENDER_LIMIT)) {
    if (!row.app || seen.has(row.app)) continue
    seen.add(row.app)
    svc.icon(row.app).then(icon => {
      if (!icon) return
      document.querySelectorAll('[data-app="' + CSS.escape(row.app) + '"]').forEach(img => {
        img.src = icon
        img.classList.remove('placeholder')
      })
    })
  }
}

function rowHtml(p, index) {
  const ports = p.listen.length ? p.listen.join(', ') : (p.conn.length ? p.conn.length + ' 连接' : '')
  return '<div class="row' + (index === state.selected ? ' selected' : '') + '" data-index="' + index + '" data-pid="' + p.pid + '">' +
    '<span class="col-name">' +
      '<img class="icon placeholder" data-app="' + (p.app || '') + '" alt="" />' +
      '<span class="name-wrap"><span class="name">' + escapeHtml(p.name) + '</span>' +
      '<span class="path" title="' + escapeHtml(p.path) + '">' + escapeHtml(p.path) + '</span></span>' +
    '</span>' +
    '<span class="col-pid">' + p.pid + '</span>' +
    '<span class="col-port' + (p.listen.length ? ' has-port' : '') + '" title="' + escapeHtml(ports) + '">' + escapeHtml(ports) + '</span>' +
    '<span class="col-cpu">' + (p.cpu ? p.cpu.toFixed(1) + '%' : '-') + '</span>' +
    '<span class="col-mem">' + fmtMem(p.rss) + '</span>' +
  '</div>'
}

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
}

function render() {
  const shown = state.rows.slice(0, RENDER_LIMIT)
  listEl.innerHTML = shown.map(rowHtml).join('')
  emptyEl.hidden = shown.length > 0
  summaryEl.textContent = state.loading
    ? '正在读取进程…'
    : state.rows.length + ' 个进程' + (state.rows.length > RENDER_LIMIT ? '（显示前 ' + RENDER_LIMIT + ' 个）' : '')
  bannerEl.hidden = !state.portWarning
  if (state.portWarning) bannerEl.textContent = state.portWarning
  loadIcons()
  const sel = listEl.querySelector('.row.selected')
  if (sel) sel.scrollIntoView({ block: 'nearest' })
}

function select(index) {
  if (!state.rows.length) return
  state.selected = Math.max(0, Math.min(index, state.rows.length - 1))
  render()
}

async function refresh() {
  if (state.loading) return
  state.loading = true
  summaryEl.textContent = '正在读取进程…'
  const data = await svc.snapshot()
  state.loading = false
  state.all = data.processes || []
  state.portWarning = data.portWarning || (data.error ? '读取失败：' + data.error : null)
  applyFilter()
}

let toastTimer = null
function toast(msg) {
  toastEl.textContent = msg
  toastEl.hidden = false
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastEl.hidden = true }, 2200)
}

const REASON = {
  permission: '权限不足，无法关闭该进程',
  gone: '进程已退出',
  self: '不能关闭插件自身',
  still_alive: '进程未响应 SIGTERM，可再试强制结束',
  invalid_pid: '无效的进程号',
  failed: '操作失败',
  not_an_app: '该进程不是 .app，不支持重启',
  spawn_failed: '启动失败'
}

async function doKill(proc, force) {
  const rowEl = listEl.querySelector('.row[data-pid="' + proc.pid + '"]')
  if (rowEl) rowEl.classList.add('removing')
  const result = force ? await svc.forceKill(proc.pid) : await svc.kill(proc.pid)
  if (result && result.ok) {
    toast('已关闭 ' + proc.name + '（' + (result.signal || 'SIGKILL') + '）')
    await refresh()
  } else {
    if (rowEl) rowEl.classList.remove('removing')
    toast(REASON[result && result.reason] || '关闭失败')
  }
}

async function doRestart(proc) {
  const stopped = await svc.kill(proc.pid)
  if (stopped && stopped.ok) {
    const result = await svc.restart(proc.pid, { app: proc.app })
    toast(result && result.ok ? '已重启 ' + proc.name : '已关闭，但重启失败：' + (REASON[result && result.reason] || ''))
  } else if (stopped && stopped.reason === 'gone') {
    const result = await svc.restart(proc.pid, { app: proc.app })
    toast(result && result.ok ? '已重启 ' + proc.name : '重启失败：' + (REASON[result && result.reason] || ''))
  } else {
    toast(REASON[stopped && stopped.reason] || '关闭失败')
  }
  await refresh()
}

async function showDetail(proc) {
  $('#dialog-title').textContent = proc.name + '  ·  PID ' + proc.pid
  const detail = await svc.detail(proc.pid)
  const lines = [
    '路径: ' + proc.path,
    '启动命令: ' + (detail.command || '（无）'),
    '用户: ' + proc.user,
    '父进程: ' + proc.ppid,
    '内存: ' + fmtMem(proc.rss) + '（' + proc.mem.toFixed(1) + '%）',
    'CPU: ' + (proc.cpu ? proc.cpu.toFixed(1) + '%（累计值）' : '-'),
    '监听端口: ' + (proc.listen.join(', ') || '无'),
    '已建立连接端口: ' + (proc.conn.join(', ') || '无'),
    '应用包: ' + (proc.app || '非 .app')
  ]
  $('#dialog-body').textContent = lines.join('\n')
  $('#dialog').hidden = false
}

function hideDialog() { $('#dialog').hidden = true }

function copyPath(proc) {
  const ok = svc.copy(proc.path)
  toast(ok ? '已复制路径' : '复制失败')
}

function reveal(proc) {
  svc.reveal(proc.app || proc.path)
}

function openMenu(x, y, proc) {
  menuEl.innerHTML = [
    '<button data-act="kill" class="danger">关闭进程</button>',
    '<button data-act="force" class="danger">强制结束（SIGKILL）</button>',
    '<button data-act="restart">重启进程</button>',
    '<div class="sep"></div>',
    '<button data-act="detail">查看详情</button>',
    '<button data-act="copy">复制路径</button>',
    '<button data-act="reveal">在文件夹中显示</button>'
  ].join('')
  menuEl.hidden = false
  const rect = menuEl.getBoundingClientRect()
  menuEl.style.left = Math.min(x, window.innerWidth - rect.width - 8) + 'px'
  menuEl.style.top = Math.min(y, window.innerHeight - rect.height - 8) + 'px'
  menuEl._proc = proc
}

function closeMenu() { menuEl.hidden = true }

function selectedProc() { return state.rows[state.selected] }

function currentProcFromMenu() { return menuEl._proc }

document.addEventListener('click', e => {
  if (!menuEl.hidden && !menuEl.contains(e.target)) closeMenu()
})

menuEl.addEventListener('click', async e => {
  const btn = e.target.closest('button[data-act]')
  if (!btn) return
  const proc = currentProcFromMenu()
  if (!proc) return
  closeMenu()
  const act = btn.dataset.act
  if (act === 'kill') await doKill(proc, false)
  else if (act === 'force') await doKill(proc, true)
  else if (act === 'restart') await doRestart(proc)
  else if (act === 'detail') await showDetail(proc)
  else if (act === 'copy') copyPath(proc)
  else if (act === 'reveal') reveal(proc)
})

listEl.addEventListener('click', e => {
  const row = e.target.closest('.row')
  if (!row) return
  state.selected = Number(row.dataset.index)
  render()
})

listEl.addEventListener('contextmenu', e => {
  const row = e.target.closest('.row')
  if (!row) return
  e.preventDefault()
  const index = Number(row.dataset.index)
  state.selected = index
  render()
  openMenu(e.clientX, e.clientY, state.rows[index])
})

listEl.addEventListener('dblclick', e => {
  const row = e.target.closest('.row')
  if (!row) return
  showDetail(state.rows[Number(row.dataset.index)])
})

searchEl.addEventListener('input', () => {
  state.keyword = searchEl.value.trim()
  state.selected = 0
  applyFilter()
})

document.querySelectorAll('#sorts button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#sorts button').forEach(b => b.classList.remove('active'))
    btn.classList.add('active')
    state.sort = btn.dataset.sort
    state.rows = sortRows(state.rows, state.sort)
    state.selected = 0
    render()
  })
})

$('#refresh').addEventListener('click', refresh)
$('#dialog-close').addEventListener('click', hideDialog)
$('#dialog').addEventListener('click', e => { if (e.target.id === 'dialog') hideDialog() })

document.addEventListener('keydown', async e => {
  if (!$('#dialog').hidden) {
    if (e.key === 'Escape') { e.preventDefault(); hideDialog() }
    return
  }
  if (e.key === 'ArrowDown') { e.preventDefault(); select(state.selected + 1) }
  else if (e.key === 'ArrowUp') { e.preventDefault(); select(state.selected - 1) }
  else if (e.key === 'Enter') {
    const proc = selectedProc()
    if (!proc) return
    e.preventDefault()
    if (e.metaKey || e.ctrlKey) await doRestart(proc)
    else if (e.shiftKey) await showDetail(proc)
    else await doKill(proc, false)
  } else if (e.key === 'Escape') {
    closeMenu()
  } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'r') {
    e.preventDefault(); refresh()
  } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'c' && selectedProc()) {
    const active = document.activeElement
    if (active === searchEl) return
    copyPath(selectedProc())
  }
})

const ztools = window.ztools || window.utools
if (ztools && typeof ztools.onPluginEnter === 'function') {
  ztools.onPluginEnter(() => {
    searchEl.focus()
    refresh()
  })
}

refresh()
